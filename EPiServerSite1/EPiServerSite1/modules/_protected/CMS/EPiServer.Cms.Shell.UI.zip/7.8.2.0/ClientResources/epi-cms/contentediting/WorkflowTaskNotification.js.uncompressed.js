﻿define("epi-cms/contentediting/WorkflowTaskNotification", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",
// dojox
    "dojox/html/entities",
// epi
    "epi/datetime",
    "epi/string",

    "epi-cms/contentediting/_ContentEditingNotification",
    "epi-cms/contentediting/command/WorkflowTask",
// resources
    "epi/i18n!epi/ui/nls/personalization.task"
],

function (
// dojo
    array,
    declare,
    lang,
    topic,
// dojox
    htmlEntities,
// epi
    epiDateTime,
    epiString,

    _ContentEditingNotification,
    WorkflowTask,
// resources
    resources
) {

    // summary:
    //      Workflow task notification
    // description:
    //      Show notification for workflow task on a related page
    // tags:
    //      public

    return declare([_ContentEditingNotification], {

        // _contentData: Object
        //      The content data regarding to the workflow task
        _contentData: null,

        taskStatus: [
            "statusnotstarted", // The tast has not started yet
            "statusinprogress", // The task is in progress
            "statuscompleted", // The task has been completed
            "statusrejected" // The task has been rejected.
        ],

        constructor: function () {
            this._storeName = "epi.cms.workflowtask";

            this.inherited(arguments);
        },

        _executeAction: function (/*Object*/content) {
            // summary:
            //      Get related workflow task(s) from its store
            // tags:
            //      protected, extension

            this._contentData = content;
            return this._store.query({ id: content.contentLink });
        },

        _onExecuteSuccess: function (/*Array*/tasks) {
            // summary:
            //      Set notification(s) when executed success from store call
            // tags:
            //      protected

            var notifications = [];
            array.forEach(tasks, function (task) {
                notifications.push({
                    content: epiString.toHTML(this._renderMessage(task)),
                    commands: [new WorkflowTask({ model: { contentData: this._contentData, task: task } })]
                });
            }, this);

            // Update workflow task notification(s)
            this._setNotification(notifications);

            // Publish event to update MyTasks component if tasks is empty
            if (!tasks || tasks.length === 0) {
                topic.publish("/epi/cms/action/refreshmytasks");
            }

        },

        _renderMessage: function (/*Object*/task) {
            // summary:
            //      Render notification content description text that based on the given task information
            //      Message formats: "{task.status}, due date {task.dueDate}, {task.subject}"
            // tags:
            //      private

            var message = "";

            // Get the given task subject text
            message += task.subject && task.subject.length > 0 ? htmlEntities.encode(task.subject) : "-";

            // Get the given task due date text
            message += task.dueDate ? lang.replace(", {0} {1}", [resources.duedate.toLowerCase(), epiDateTime.toUserFriendlyString(task.dueDate)]) : "";

            // Get the given task status text
            message += ", " + resources[this.taskStatus[task.status]];

            return message;
        }

    });

});