﻿define("epi-cms/contentediting/ViewSettingsNotification", [
// dojo
    "dojo/_base/declare",
// epi
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/contentediting/_ContentEditingNotification",
// resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.viewsettingsnotification"
],

function (
// dojo
    declare,
// epi
    ContentActionSupport,
    _ContentEditingNotification,
// resources
    resources
) {

    // summary:
    //      Show visitorgroup notification into warning notifications for the notification bar.
    // tags:
    //      public

    return declare([_ContentEditingNotification], {

        _onExecuteSuccess: function (/*Object*/value) {
            // summary:
            //      Set notification(s) when executed success
            // tags: 
            //      protected

            var isReadOnlyUser = value.viewModel.contentData && value.viewModel.contentData.accessMask <= ContentActionSupport.accessLevel.Read,
                setNotification = isReadOnlyUser && value.viewSetting.get("enabled") && value.viewSetting.hasVisitorGroup();

            this._setNotification(setNotification ? { content: resources.visitorgroups.noaccessright} : null);
        }

    });

});