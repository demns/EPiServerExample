﻿(function (scope) {
    // summary:
    //      Handles integration between site content in preview and the edit UI.

    /* global self: true */

    var keyPrefix = "epi::",
        messageHandlers = {},
        eventHandles = [];

    function on(target, eventType, listener, capture) {
        // summary:
        //      Simple event handler registration. Returns a handle with a remove method.
        // target: Object
        //      the object to listen for events on. Must implement addEventListener.
        // eventType: String
        //      The message payload to send to the the topic listeners
        // listener: function
        //      The function to execute when the event is triggered

        var resolvedCapture = !!capture;

        target.addEventListener(eventType, listener, resolvedCapture);

        return {
            remove: function () {
                target.removeEventListener(eventType, listener, resolvedCapture);
                target = null;
            }
        };
    }

    function publish(topic, message) {
        // summary:
        //      Publishes a message using the postMessage hub.
        // topic: String
        //      The name of the topic to publish to
        // message: Object
        //      The message payload to send to the the topic listeners

        top.postMessage({ id: topic, message: message }, "*");
    }

    function subscribe(topic, handler) {
        // summary:
        //      Subscribes to a message on the postMessage hub.
        // topic: String
        //      The topic to subscribe to
        // handler: Function
        //      A function to call when a message is published to the given topic

        var key = keyPrefix + topic;

        messageHandlers[key] ? messageHandlers[key].push(handler) : messageHandlers[key] = [handler];

        return {
            remove: function() {
                var i, topicHandlers = messageHandlers[key];

                if (topicHandlers) {
                    while ((i = topicHandlers.indexOf(handler)) !== -1) {
                        topicHandlers.splice(i, 1);
                    }
                }
                handler = key = null;
            }
        };
    }

    function ready(fn) {
        // summary:
        //      Executes the provided function when the dom is ready.
        // fn: function
        //      The callback to execute when the dom is ready.

        var loadHandle;

        function load() {
            loadHandle.remove();
            loadHandle = null;
            fn && fn();
        }

        if (self.document.readyState === "complete") {
            fn && fn();
        } else {
            loadHandle = on(self.document, "DOMContentLoaded", load);
        }
    }

    function destroy() {
        eventHandles.forEach(function (handle) {
            handle.remove();
        });
        messageHandlers = eventHandles = null;
    }

    function initSizeListener() {

        var elm,
            size,
            name = window.name,
            publishTopic = "/site/resize" + (name ? "/" + name : "");

        function elementChecker() {

            if (elm) {
                if (document.body.lastChild === elm) {
                    return;
                }
                elm.parentNode.removeChild(elm);
                elm = null;
            }

            document.body.insertAdjacentHTML("beforeend", "<div id='epi-bodysize' style='position: absolute; padding: 0; margin: 0;height: 0; width: 100%;'></div>");
            elm = document.getElementById("epi-bodysize");
        }

        function sizeChecker() {
            var w, h;

            elementChecker();

            w = elm.offsetWidth;
            h = elm.offsetTop;

            if (!size || size.w != w || size.h != h) {
                size = {"h": h, "w": w };
                publish(publishTopic, size);
            }
        }

        eventHandles.push(subscribe("/site/checksize", sizeChecker));
    }

    function initMessageHandler() {

        function handleMessage(msg) {
            var handlers, msgData = msg.data;

                try {
                    if (msgData) {
                        handlers = messageHandlers[keyPrefix + msgData.id];
                        handlers && handlers.forEach(function (handler) { handler(msgData.data); });
                    }
                } catch (ex) { }
        }

        eventHandles.push(on(self, "message", handleMessage));
    }

/*
    function initFocusListener() {

        function onFocus() {
            publish("/site/focus", {});
        }

        function onBlur() {
            publish("/site/blur", {});
        }

        function onMousedown() {
            publish("/site/mousedown", {});
        }

        eventHandles.push(on(self.document, "focus", onFocus, true));
        eventHandles.push(on(self.document, "blur", onBlur, true));
        eventHandles.push(on(self.document, "mousedown", onMousedown, true));
    }
 */

    function exposeMethods() {
        scope.publish = publish;
        scope.subscribe = subscribe;
    }

    ready(function () {

        initMessageHandler();
        initSizeListener();
        exposeMethods();

        eventHandles.push(on(self, "unload", function () {
            publish("/site/unload", {});
            destroy();
        }));

        publish("/site/load", { url: self.location.href });
    });

})(window.epi = window.epi || {});
