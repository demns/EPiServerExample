﻿define("epi-cms/contentediting/viewsettings/ViewLanguageViewSetting", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Deferred",
    "epi-cms/contentediting/_ViewSetting"
],
function (declare, lang, Deferred, _ViewSetting) {
    return declare([_ViewSetting], {
        key: "viewlanguage",
        usedForRendering: true,
        isTagItem: false,

        initialize: function (contextService) {
            contextService.registerRequestInterceptor(lang.hitch(this, this._onContextChange));
        },

        _onContextChange: function (contextParams, callerData) {
            var dfd = new Deferred();
            dfd.resolve();
            if (this.get("enabled") && this.value) {
                contextParams.epslanguage = this.value;                
            }

            return dfd;
        }
    });
});