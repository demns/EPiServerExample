﻿define("epi-cms/compare/viewmodels/CompareViewModel", [
    "dojo/_base/declare",
    "dojo/topic",
    "dojo/_base/lang",
    "dojo/Stateful",
    "dojo/when",
    "dijit/Destroyable",
    "epi/dependency",
    "epi-cms/core/ContentReference"
], function(
    declare,
    topic,
    lang,
    Stateful,
    when,
    Destroyable,
    dependency,
    ContentReference
) {

    // module:
    //      epi-cms/compare/viewmodels/CompareViewModel
    // summary:
    //      View model for the compare views.
    return declare([Stateful, Destroyable], {

        // contentLink: [public] String
        //      The content link of the content to be compared.
        contentLink: null,

        // typeIdentifier: [public] String
        //      The type identifier for the content to be compared
        typeIdentifier: null,

        // leftVersion: [public] Object
        //      The version data for the version appearing in the left compare panel.
        leftVersion: null,

        // rightVersion: [public] Object
        //      The version data for the version appearing in the right compare panel.
        rightVersion: null,

        // leftVersionUri: String
        //      Uri of the left version. The left version is context bound, so we need to use URI.
        leftVersionUri: null,

        // rightVersionUrl: String
        //      Preview url of the right version. The right version is not context bound, so we handle preview URL directly.
        rightVersionUrl: null,

        // hasAccess: [public] Boolean
        //      A flag which indicates whether the current user has access to view versions.
        hasAccess: true,

        // contentDataStore: [readonly] epi/shell/RestStore
        //      The content data store
        contentDataStore: null,

        // contentVersionStore: [readonly] epi/shell/RestStore
        //      The content version store
        contentVersionStore: null,

        // orientation: [public] String
        //      Orientation of the split panels
        orientation: "vertical",

        postscript: function() {
            // summary:
            //      Setup mixed in properties
            // tags:
            //      protected
            var registry = dependency.resolve("epi.storeregistry");

            this.contentDataStore = registry.get("epi.cms.contentdata");
            this.contentVersionStore = registry.get("epi.cms.contentversion");

            this.inherited(arguments);

            // When a publish occurs we need to refresh the left and rightversion to get the new text to display
            this.own(
                topic.subscribe("/epi/cms/content/statuschange/", lang.hitch(this, "_refresh"))
            );
        },

        _refresh: function () {
            // summary:
            //      Refreshes the left and right versions with the latest data from the server
            // tags:
            //      private

            var store = this.contentVersionStore;

            when(store.refresh(this.leftVersion.contentLink), lang.hitch(this, function (version) {
                this.set("leftVersion", version);
            }));

            if (this.rightVersion) {
                when(store.refresh(this.rightVersion.contentLink), lang.hitch(this, function(version) {
                    this.set("rightVersion", version);
                }));
            }
        },

        _contentLinkSetter: function(contentLink) {
            this.contentLink = contentLink;

            var store = this.contentVersionStore;

            when(store.get(contentLink), lang.hitch(this, function (version) {
                this.set("leftVersion", version);
            }));


            if (!this.rightVersion || !ContentReference.compareIgnoreVersion(this.leftVersion.contentLink, this.rightVersion.contentLink)) {
                var queryParams = {
                    contentLink: contentLink,
                    query: "getcompareversion"
                };

                var query = store.query(queryParams);

                this.own(query.observe(lang.hitch(this, function (object, previousIndex, newIndex) {
                    if (newIndex === -1) {
                        this.set("rightVersion", null);
                    }
                })));

                when(query, lang.hitch(this, function (versions) {
                    this.set("hasAccess", true);
                    this.set("rightVersion", versions && versions.length ? versions[0] : null);
                }), lang.hitch(this, function(error) {
                    this.set("hasAccess", error.status !== 403);
                    this.set("rightVersion", null);
                }));
            }

        },

        _leftVersionSetter: function(version) {
            // summary:
            //      Sets the version data for the left compare panel.
            // tags:
            //      protected
            this.leftVersion = version;

            this.set("leftVersionUri", version.uri);
        },

        _rightVersionSetter: function(version) {
            // summary:
            //      Sets the version data for the right compare panel.
            // tags:
            //      protected

            this.rightVersion = version;

            // If the version is null then set the rightVersionUrl to null and do an early exit.
            if (version === null) {
                this.set("rightVersionUrl", "about:blank");
                return;
            }

            // Update the URL for the right panel when the version changes.
            when(this.contentDataStore.get(version.contentLink), lang.hitch(this, function(content) {
                this.set("rightVersionUrl", content.editablePreviewUrl);
            }));
        }
    });
});
